export const basePath = "http://localhost:3977/api";
export const apiVersion = "v1";
