import React from "react";

export default function Admin(){
    return (
        <div>
            <h2>Admin page</h2>
        </div>
    )
}