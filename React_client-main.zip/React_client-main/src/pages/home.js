import React from "react";

export default function Home() {
  return (
    <div>
      <h1>Cardssss</h1>
      <h6>Content</h6>
    </div>

  );
}